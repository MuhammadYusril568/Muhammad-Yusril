package akademisyu;

public class Main {
    public static void main(String[] args) {

        Mahasiswa mhs = new Mahasiswa("2410020120", "Yusril", 3.8, 4);
        mhs.tampil();

        System.out.println("------------------");

        MataKuliah mk = new MataKuliah("IF101", "Pemrograman");
        mk.tampil();
    }
}