/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.akademisyuapp;

/**
 *
 * @author USER
 */
public class AkademisyuAPP {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
